import React, { useState, useEffect } from "react";
import axios from "axios";
import CommentsComponent from "./CommentsComponent.jsx";
import { Row, Col, Button, Card } from "antd";
import SpinnerComponent from "./SpinnerComponent.jsx";

const CommentsHomeComponent = () => {
  const [commentList, setCommentList] = useState([]);
  const [loader, setLoader] = useState(true);

  useEffect(() => {
    fetchPost();
  });


  const fetchPost = ()=> {
    axios.get("http://localhost:3001/posts").then((res) => {
      console.log(res.data?.data);
      setCommentList(res?.data?.data);
      setLoader(false);
    });
  }

  const refreshHandler = ()=> {
    setLoader(true);
    fetchPost();
  }
  return (
    <>
    { !loader && commentList && commentList.length > 0 ? (
      <>
      <Card>
      <div className="comment__wrapper">
        <CommentsComponent commentList={commentList} />
      </div>
      <Row gutter={[24]} className="btn__row">
        <Col>
          <Button type="primary" onClick={refreshHandler}> Refresh</Button>
        </Col>
      </Row>
      </Card>
      </>
    ): (<SpinnerComponent/>)}
      
    </>
  );
};

export default CommentsHomeComponent;
