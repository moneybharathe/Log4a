import { PageHeader } from 'antd';
import { useHistory } from 'react-router';

const HomeComponent = ()=> {

    const history = useHistory();


    return(
        <PageHeader
    className="site-page-header"
    onBack={() => history.push('/comments')}
    title="Welcome to Comments Page"
    subTitle="comment "
  />
    );
}


export default HomeComponent;