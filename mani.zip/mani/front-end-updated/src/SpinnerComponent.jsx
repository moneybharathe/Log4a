import { Spin, Space } from 'antd';

const SpinnerComponent = ()=> (
    <Space size="middle">    
    <Spin size="large" />
  </Space>
)


export default SpinnerComponent;