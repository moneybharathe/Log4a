import "./App.css";
// import logo from "./logo.png";
// import { version } from "../package.json";
import { BrowserRouter, Switch, Route } from "react-router-dom";
import { Layout } from "antd";
import CommentsHomeComponent from "./CommentsHomeComponent.jsx";
import HomeComponent from "./HomeComponent";

const { Header, Footer, Sider, Content } = Layout;

const App = () => (
  // <div className="App">
  //   <header className="App-header">
  //     <img src={logo} className="App-logo" alt="logo" />

  //     <p>Welcome to the Message Broadcast Code Exercise,</p>

  //     <p>Good luck!</p>

  //     <small style={{ position: "absolute", bottom: "10px" }}>v{version}</small>
  //   </header>
  // </div>

  <Layout>
    <Header>Header</Header>
    <Content>
      <BrowserRouter>
      <Switch>
        <Route path="/comments" component={CommentsHomeComponent} />
        <Route exact path="/" component={HomeComponent} />
      </Switch>
      </BrowserRouter>
    </Content>
    <Footer>Footer</Footer>
  </Layout>
);

export default App;
