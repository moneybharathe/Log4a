import React from "react";
import { List, Card, Row, Col, Button } from "antd";

const CommentsComponent = ({ commentList }) => {
  return (
    <>
    

<List
    grid={{ gutter: 16, column: 4 }}
    dataSource={commentList}
    renderItem={item => (
      <List.Item>
        <Card title={item.email}>
          <h4>
            {item.name}
          </h4>
          <p>{item.body}</p>
        </Card>
      </List.Item>
    )}
  />

 
      
    </>
  );
};

export default CommentsComponent;
