const express = require("express");
const router = express.Router();
const axios = require("axios");
const sqlite3 = require("sqlite3").verbose();

const fs = require("fs");

//create db in in memory

let db = new sqlite3.Database(":memory:", (err) => {
  if (err) {
    return console.log(err.message);
  }
  console.log("Connected to the in memory database");
});

//closing the database; to avoid memory leak

db.close((err) => {
  if (err) {
    return console.log(err.message);
  }
  console.log("Closing the databse connection");
});

/* GET home page. */
router.get("/posts", async (req, res) => {
  // res.render("index", { title: "Express" });

  const response = await axios.get(
    "https://jsonplaceholder.typicode.com/comments "
  );

  fs.writeFileSync("demo.db");

  res.send({ data: response.data });
});

module.exports = router;
